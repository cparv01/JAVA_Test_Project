package com.testProject.TestProject.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserOTP {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String otp;

    @ManyToOne
    @JoinColumn(name = "user_id")  // Foreign key to User table
    private User user;  // Reference to the user entity

    @Column(nullable = false)
    private Timestamp createdAt;

    @Column(nullable = false)
    private Integer status = 0;

    // Add other fields as needed
}
