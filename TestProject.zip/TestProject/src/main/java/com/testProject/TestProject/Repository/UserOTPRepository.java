package com.testProject.TestProject.Repository;

import com.testProject.TestProject.Entity.UserOTP;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserOTPRepository extends JpaRepository<UserOTP, Long> {
    // You can add custom queries if needed, e.g., find OTP by user
//    List<UserOTP> findAllByUserId(Long userId);

    Optional<UserOTP> findByOtpAndStatus(String otp, Integer status);


//    @Query("SELECT u FROM UserOTP u WHERE u.user.id = :userId ORDER BY u.createdAt DESC")
//    Optional<UserOTP> findLatestOtpByUserId(@Param("userId") Long userId);
}
